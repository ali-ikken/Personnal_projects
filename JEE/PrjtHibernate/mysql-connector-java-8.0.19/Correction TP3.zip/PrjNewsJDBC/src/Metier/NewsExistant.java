package Metier;

public class NewsExistant extends Exception {
	private static final long serialVersionUID = 1L;

	public NewsExistant(String msg) {
		super(msg);
	}
}
